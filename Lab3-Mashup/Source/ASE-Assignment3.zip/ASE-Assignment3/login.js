/**
 * Created by NSB on 9/19/16.
 */
angular.module('GoogleLogin', ['googleOauth']).

config(function(TokenProvider) {
    // Demo configuration for the "angular-oauth demo" project on Google.
    // Log in at will!

    // Sorry about this way of getting a relative URL, powers that be.

    var getUrl = window.location;
    var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
    console.log(baseUrl);
    TokenProvider.extendConfig({
        clientId: '1004413881415-el3modfh25g6gn4up13tl1l5o13rir41.apps.googleusercontent.com',
        redirectUri: baseUrl+"/oauth2callback.html",  // allow lunching demo from a mirror
        scopes: ["https://www.googleapis.com/auth/userinfo.email"]
    });
}).

controller('LoginCtrl', function($rootScope, $scope, $window, Token) {
    $scope.accessToken = Token.get();
    $scope.authenticate = function() {
        console.log($scope.accessToken);
        var extraParams = $scope.askApproval ? {approval_prompt: 'force'} : {};
        Token.getTokenByPopup(extraParams)
            .then(function(params) {
                // Success getting token from popup.

                // Verify the token before setting it, to avoid the confused deputy problem.
                Token.verifyAsync(params.access_token).
                then(function(data) {
                    $rootScope.$apply(function() {
                        $scope.accessToken = params.access_token;
                        $scope.expiresIn = params.expires_in;
                        Token.set(params.access_token);
                        if($scope.accessToken != null)
                        {
                            window.open("../ASE-Assignment3/login2.html");
                        }
                    });
                }, function() {
                    alert("Failed to verify token.");
                });

            }, function() {
                // Failure getting token from popup.
                alert("Failed to get token from popup.");
            });
    };
});